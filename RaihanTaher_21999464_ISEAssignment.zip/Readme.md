## Synopsis
Final Assessment of Introduction to Software Engineering ISAD5004

## Contents
code/main.py - main program 
code/testCode.py  - test code
code/input.txt - input for Helper.test_life_path_number 
documents/RaihanTaher_21999464_ISEReport.md - Report in md format
documents/RaihanTaher_21999464_ISEReport.md - Report in pdf format
documents/Cover_ISAD_21999464.pdf - Declaration of originality
README.md
.gitignore
 
## Dependencies
unittest
sys
os
io
datetime
 